const QUOTES = [
  "The secret of getting ahead is getting started.",
  "Your time is limited, don't waste it living someone else's life.",
  "Lost time is never found again.",
  "Either you run the day or the day runs you.",
  "It's not that we have little time, but that we waste a great deal of it.",
  "The key is in not spending time, but in investing it.",
  "Time is the most valuable thing a man can spend.",
  "Time flies over us, but leaves its shadow behind.",
];

const params = new URLSearchParams(window.location.search);
const siteName = params.get("site") || "unknown.com";

const EMOJI_MAP = {
  "youtube.com": "📺", "twitter.com": "🐦", "x.com": "🐦",
  "instagram.com": "📸", "facebook.com": "👥", "reddit.com": "🤖",
  "tiktok.com": "🎵", "netflix.com": "🎬", "twitch.tv": "🎮",
  "linkedin.com": "💼", "github.com": "💻"
};

document.addEventListener("DOMContentLoaded", async () => {
  document.getElementById("siteName").textContent = siteName;
  document.getElementById("siteEmoji").textContent = EMOJI_MAP[siteName] || "🌐";
  document.getElementById("quoteText").textContent =
    `"${QUOTES[Math.floor(Math.random() * QUOTES.length)]}"`;

  // Load stats
  try {
    const data = await chrome.runtime.sendMessage({ type: "GET_ALL_STATS" });
    const limits = data?.limits || {};
    const todayData = data?.todayData || {};
    const cfg = limits[siteName];

    if (cfg) {
      const spent = todayData[siteName] || cfg.limit;
      const over = Math.max(0, spent - cfg.limit);
      document.getElementById("timeSpent").textContent = formatTime(spent);
      document.getElementById("limitSet").textContent = formatTime(cfg.limit);
      document.getElementById("overLimit").textContent = formatTime(over);

      if (!data?.settings?.allowOverride) {
        document.getElementById("overrideBtn").style.display = "none";
      }
    }
  } catch (e) {}

  startCountdown();
});

function startCountdown() {
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  const totalMs = 24 * 60 * 60 * 1000;

  function tick() {
    const remaining = midnight - Date.now();
    if (remaining <= 0) {
      document.getElementById("countdown").textContent = "00:00:00";
      document.getElementById("resetProgress").style.width = "100%";
      return;
    }
    const h = Math.floor(remaining / 3600000);
    const m = Math.floor((remaining % 3600000) / 60000);
    const s = Math.floor((remaining % 60000) / 1000);
    document.getElementById("countdown").textContent =
      `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`;

    const elapsed = totalMs - remaining;
    document.getElementById("resetProgress").style.width = `${(elapsed / totalMs) * 100}%`;
  }

  tick();
  setInterval(tick, 1000);
}

function goHome() {
  chrome.tabs.update({ url: "chrome://newtab" });
}

async function tryOverride() {
  const btn = document.getElementById("overrideBtn");
  btn.disabled = true;
  btn.textContent = "⏳ Processing...";

  try {
    await chrome.runtime.sendMessage({ type: "OVERRIDE", hostname: siteName });
    document.getElementById("overrideMsg").textContent =
      "✅ 30 minutes granted! Use them wisely!";
    document.getElementById("overrideMsg").style.color = "#00A86B";
    setTimeout(() => {
      history.back();
    }, 1500);
  } catch (e) {
    btn.disabled = false;
    btn.textContent = "⚡ OVERRIDE (JUST 30 MORE MINUTES)";
  }
}

function formatTime(seconds) {
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m`;
  return `${s}s`;
}
