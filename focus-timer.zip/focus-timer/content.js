// =============================================
// FOCUS TIMER — Content Script
// =============================================

let badge = null;
let warningShown = false;
let checkInterval = null;

const hostname = window.location.hostname.replace("www.", "");

async function init() {
  const response = await sendMsg({ type: "GET_STATUS", hostname });
  if (!response?.cfg?.enabled) return;
  createBadge();
  startChecking();
}

function createBadge() {
  if (badge || !document.body) return;
  badge = document.createElement("div");
  badge.id = "ft-badge";
  badge.innerHTML = `
    <div id="ft-inner">
      <span id="ft-icon">⏱</span>
      <span id="ft-time">--:--</span>
    </div>
  `;
  const style = document.createElement("style");
  style.textContent = `
    #ft-badge {
      position: fixed;
      bottom: 20px;
      right: 20px;
      z-index: 2147483647;
      font-family: 'Arial Black', sans-serif;
      cursor: pointer;
      transition: all 0.3s ease;
    }
    #ft-inner {
      display: flex;
      align-items: center;
      gap: 6px;
      padding: 8px 14px;
      background: #FFE600;
      border: 3px solid #0A0A0A;
      border-radius: 6px;
      box-shadow: 4px 4px 0 #0A0A0A;
      font-size: 13px;
      font-weight: 900;
      color: #0A0A0A;
      user-select: none;
    }
    #ft-badge.warning #ft-inner {
      background: #FF6B00;
      color: #fff;
      animation: ft-pulse 1s infinite;
    }
    #ft-badge.danger #ft-inner {
      background: #FF3CAC;
      color: #fff;
      animation: ft-pulse 0.5s infinite;
    }
    #ft-badge.hidden-badge { opacity: 0; pointer-events: none; }
    @keyframes ft-pulse {
      0%, 100% { transform: scale(1); }
      50% { transform: scale(1.05); }
    }
    /* Warning overlay */
    #ft-overlay {
      position: fixed;
      inset: 0;
      background: rgba(10,10,10,0.85);
      z-index: 2147483646;
      display: flex;
      align-items: center;
      justify-content: center;
      font-family: 'Arial Black', sans-serif;
    }
    #ft-overlay-box {
      background: #FFE600;
      border: 5px solid #0A0A0A;
      border-radius: 12px;
      box-shadow: 8px 8px 0 #0A0A0A;
      padding: 40px;
      max-width: 420px;
      width: 90%;
      text-align: center;
    }
    #ft-overlay-box h2 { font-size: 32px; margin: 0 0 12px; color: #0A0A0A; }
    #ft-overlay-box p { font-size: 16px; color: #0A0A0A; margin: 0 0 24px; font-weight: 700; }
    .ft-btn {
      display: inline-block;
      padding: 12px 28px;
      border: 3px solid #0A0A0A;
      border-radius: 6px;
      box-shadow: 4px 4px 0 #0A0A0A;
      font-weight: 900;
      font-size: 14px;
      cursor: pointer;
      margin: 6px;
      background: #0A0A0A;
      color: #FFE600;
      text-transform: uppercase;
      letter-spacing: 1px;
    }
    .ft-btn:hover { transform: translate(-2px,-2px); box-shadow: 6px 6px 0 #0A0A0A; }
    .ft-btn.secondary { background: #fff; color: #0A0A0A; }
  `;
  document.head.appendChild(style);
  document.body.appendChild(badge);

  badge.addEventListener("click", () => {
    badge.classList.toggle("hidden-badge");
    setTimeout(() => badge.classList.remove("hidden-badge"), 5000);
  });
}

function startChecking() {
  update();
  checkInterval = setInterval(update, 3000);
}

async function update() {
  const resp = await sendMsg({ type: "GET_STATUS", hostname });
  if (!resp?.cfg?.enabled) return;

  const { cfg, spent, isBlocked } = resp;
  if (isBlocked) {
    window.location.href = chrome.runtime.getURL(`blocked.html?site=${encodeURIComponent(hostname)}`);
    return;
  }

  const remaining = Math.max(0, cfg.limit - spent);
  const pct = (spent / cfg.limit) * 100;

  if (badge) {
    const el = badge.querySelector("#ft-time");
    if (el) el.textContent = formatTime(remaining);
    badge.className = pct >= 90 ? "danger" : pct >= 70 ? "warning" : "";

    if (pct >= 90 && !warningShown) {
      warningShown = true;
      showWarningOverlay(remaining, hostname);
    }
  }
}

function showWarningOverlay(remaining, site) {
  const existing = document.getElementById("ft-overlay");
  if (existing) return;

  const overlay = document.createElement("div");
  overlay.id = "ft-overlay";
  overlay.innerHTML = `
    <div id="ft-overlay-box">
      <div style="font-size:48px;margin-bottom:8px">⚠️</div>
      <h2>TIME RUNNING OUT!</h2>
      <p>You have <strong>${formatTime(remaining)}</strong> left on <strong>${site}</strong> today.</p>
      <p style="font-size:13px;opacity:0.8;margin-bottom:20px">Make it count or wrap up!</p>
      <button class="ft-btn" onclick="document.getElementById('ft-overlay').remove()">GOT IT, KEEP GOING</button>
      <button class="ft-btn secondary" onclick="window.history.back()">GO BACK</button>
    </div>
  `;
  document.body.appendChild(overlay);
  setTimeout(() => overlay.remove(), 10000);
}

function formatTime(seconds) {
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${String(sec).padStart(2, "0")}s`;
  return `${sec}s`;
}

function sendMsg(msg) {
  return chrome.runtime.sendMessage(msg).catch(() => null);
}

// Run
if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", init);
} else {
  init();
}
