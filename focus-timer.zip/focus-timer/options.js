document.addEventListener("DOMContentLoaded", async () => {
  const data = await chrome.storage.local.get("settings");
  const s = data.settings || {};

  document.getElementById("notifications").checked = s.notifications !== false;
  document.getElementById("showBadge").checked = s.showBadge !== false;
  document.getElementById("strictMode").checked = !!s.strictMode;
  document.getElementById("allowOverride").checked = s.allowOverride !== false;

  const warnSlider = document.getElementById("warningPercent");
  const warnVal = document.getElementById("warningVal");
  warnSlider.value = s.warningPercent || 80;
  warnVal.textContent = warnSlider.value + "%";
  warnSlider.addEventListener("input", () => warnVal.textContent = warnSlider.value + "%");

  const overrideSlider = document.getElementById("overrideCooldown");
  const overrideVal = document.getElementById("overrideVal");
  overrideSlider.value = s.overrideCooldown || 30;
  overrideVal.textContent = overrideSlider.value + "m";
  overrideSlider.addEventListener("input", () => overrideVal.textContent = overrideSlider.value + "m");
});

async function saveSettings() {
  const settings = {
    notifications: document.getElementById("notifications").checked,
    showBadge: document.getElementById("showBadge").checked,
    strictMode: document.getElementById("strictMode").checked,
    allowOverride: document.getElementById("allowOverride").checked,
    warningPercent: parseInt(document.getElementById("warningPercent").value),
    overrideCooldown: parseInt(document.getElementById("overrideCooldown").value),
  };
  await chrome.runtime.sendMessage({ type: "SAVE_SETTINGS", settings });
  showToast();
}

async function resetToday() {
  if (!confirm("Reset today's tracking data?")) return;
  const data = await chrome.storage.local.get("dailyTime");
  const dt = data.dailyTime || {};
  const today = new Date().toISOString().split("T")[0];
  delete dt[today];
  await chrome.storage.local.set({ dailyTime: dt, blocked: {} });
  showToast("✅ Today's stats reset!");
}

async function clearAll() {
  if (!confirm("⚠️ Delete ALL data? This cannot be undone!")) return;
  await chrome.storage.local.clear();
  showToast("🗑 All data cleared!");
}

function showToast(msg = "✅ Settings saved!") {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 2500);
}
