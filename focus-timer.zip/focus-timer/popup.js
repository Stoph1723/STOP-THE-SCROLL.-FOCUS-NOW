// =============================================
// FOCUS TIMER — Popup Script
// =============================================

let currentHostname = "";
let editingHostname = null;
let selectedColor = "#FFE600";
let allData = {};
let updateInterval = null;

const COLORS = ["#FFE600","#FF3CAC","#00D4FF","#00FF85","#FF6B00","#8B5CF6"];

// ── Init ──────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  await loadCurrentTab();
  await loadAllData();
  setupTabs();
  setupModal();
  setupButtons();
  updateInterval = setInterval(refreshCurrentSite, 2000);
});

window.addEventListener("unload", () => {
  clearInterval(updateInterval);
});

async function loadCurrentTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url || !tab.url.startsWith("http")) {
      showNoSite();
      return;
    }
    currentHostname = new URL(tab.url).hostname.replace("www.", "");
    await refreshCurrentSite();
  } catch (e) {
    showNoSite();
  }
}

async function refreshCurrentSite() {
  if (!currentHostname) return;
  try {
    const resp = await sendMsg({ type: "GET_STATUS", hostname: currentHostname });
    renderCurrentSite(resp);
  } catch (e) {}
}

async function loadAllData() {
  try {
    allData = await sendMsg({ type: "GET_ALL_STATS" });
    renderSitesList();
    renderStats();
    updateAddButton();
  } catch (e) {}
}

// ── Render Current Site ───────────────────────
function renderCurrentSite(resp) {
  const { hostname, cfg, spent, isBlocked } = resp || {};

  document.getElementById("siteName").textContent = hostname || "Unknown";
  
  // Favicon emoji based on domain
  const favicon = document.getElementById("siteFavicon");
  favicon.textContent = getDomainEmoji(hostname);

  if (!cfg?.enabled) {
    document.getElementById("timerWrap").style.display = "none";
    document.getElementById("notTrackedMsg").style.display = "block";
    document.getElementById("siteStatus").textContent = "No limit set";
    document.getElementById("siteStatus").style.color = "#888";
    document.getElementById("addCurrentBtn").style.display = "flex";
    return;
  }

  document.getElementById("timerWrap").style.display = "flex";
  document.getElementById("notTrackedMsg").style.display = "none";
  document.getElementById("addCurrentBtn").style.display = "none";

  const remaining = Math.max(0, cfg.limit - spent);
  const pct = Math.min(100, (spent / cfg.limit) * 100);

  // Circular arc
  const arc = document.getElementById("timerArc");
  const offset = 283 - (283 * (1 - pct / 100));
  arc.style.strokeDashoffset = offset;
  arc.style.stroke = pct >= 90 ? "#FF3CAC" : pct >= 70 ? "#FF6B00" : "#00FF85";

  document.getElementById("timerTime").textContent = formatTime(remaining);
  document.getElementById("statSpent").textContent = formatTime(spent);
  document.getElementById("statLimit").textContent = formatTime(cfg.limit);

  const statusEl = document.getElementById("statStatus");
  if (isBlocked) {
    statusEl.textContent = "BLOCKED";
    statusEl.className = "stat-val red";
    document.getElementById("siteStatus").textContent = "⛔ Time limit reached";
    document.getElementById("siteStatus").style.color = "#FF3CAC";
  } else if (pct >= 90) {
    statusEl.textContent = "DANGER";
    statusEl.className = "stat-val red";
    document.getElementById("siteStatus").textContent = "⚠️ Almost at limit";
    document.getElementById("siteStatus").style.color = "#FF6B00";
  } else if (pct >= 70) {
    statusEl.textContent = "WARNING";
    statusEl.className = "stat-val orange";
    document.getElementById("siteStatus").textContent = `⏱ ${Math.round(pct)}% used`;
    document.getElementById("siteStatus").style.color = "#FF6B00";
  } else {
    statusEl.textContent = "OK";
    statusEl.className = "stat-val green";
    document.getElementById("siteStatus").textContent = `✅ ${Math.round(pct)}% used`;
    document.getElementById("siteStatus").style.color = "#00A86B";
  }
}

function showNoSite() {
  document.getElementById("siteName").textContent = "No website";
  document.getElementById("siteStatus").textContent = "Open a website to track";
  document.getElementById("timerWrap").style.display = "none";
  document.getElementById("notTrackedMsg").style.display = "none";
}

function updateAddButton() {
  const limits = allData?.limits || {};
  const btn = document.getElementById("addCurrentBtn");
  if (limits[currentHostname]?.enabled) {
    btn.style.display = "none";
  } else {
    btn.style.display = "flex";
  }
}

// ── Sites List ────────────────────────────────
function renderSitesList() {
  const limits = allData?.limits || {};
  const todayData = allData?.todayData || {};
  const blocked = allData?.blocked || {};
  const list = document.getElementById("sitesList");

  const entries = Object.entries(limits);
  if (entries.length === 0) {
    list.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🚫</div>
        <p>No sites added yet.<br/>Add a limit to get started!</p>
      </div>`;
    return;
  }

  list.innerHTML = "";
  entries.forEach(([hostname, cfg]) => {
    const spent = todayData[hostname] || 0;
    const pct = Math.min(100, (spent / cfg.limit) * 100);
    const isBlocked = !!blocked[hostname];
    const remaining = Math.max(0, cfg.limit - spent);

    const item = document.createElement("div");
    item.className = "site-item";
    item.innerHTML = `
      <div class="site-item-header">
        <div class="site-color-dot" style="background:${cfg.color || '#FFE600'}"></div>
        <span class="site-item-name">
          ${hostname}
          ${isBlocked ? '<span class="blocked-badge">BLOCKED</span>' : ""}
        </span>
        <div class="site-item-actions">
          <label class="toggle" title="Enable/Disable">
            <input type="checkbox" ${cfg.enabled ? "checked" : ""} data-host="${hostname}">
            <div class="toggle-track"></div>
            <div class="toggle-thumb"></div>
          </label>
          <button class="mini-btn rst" title="Reset Today" data-host="${hostname}" data-action="reset">🔄</button>
          <button class="mini-btn" title="Edit" data-host="${hostname}" data-action="edit">✏️</button>
          <button class="mini-btn del" title="Delete" data-host="${hostname}" data-action="delete">🗑</button>
        </div>
      </div>
      <div class="site-progress-wrap">
        <div class="progress-labels">
          <span>${formatTime(spent)} used</span>
          <span>${formatTime(remaining)} left</span>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width:${pct}%;background:${
            pct >= 90 ? "#FF3CAC" : pct >= 70 ? "#FF6B00" : cfg.color || "#FFE600"
          }"></div>
        </div>
      </div>
    `;
    list.appendChild(item);

    // Toggle
    item.querySelector(`input[data-host="${hostname}"]`).addEventListener("change", async (e) => {
      await sendMsg({ type: "TOGGLE_LIMIT", hostname });
      await loadAllData();
    });

    // Actions
    item.querySelectorAll("[data-action]").forEach(btn => {
      btn.addEventListener("click", async (e) => {
        const action = btn.dataset.action;
        const host = btn.dataset.host;
        if (action === "delete") {
          if (confirm(`Delete limit for ${host}?`)) {
            await sendMsg({ type: "DELETE_LIMIT", hostname: host });
            await loadAllData();
          }
        } else if (action === "edit") {
          openModal(host);
        } else if (action === "reset") {
          await sendMsg({ type: "RESET_SITE", hostname: host });
          await loadAllData();
          refreshCurrentSite();
        }
      });
    });
  });
}

// ── Stats ─────────────────────────────────────
function renderStats() {
  const limits = allData?.limits || {};
  const todayData = allData?.todayData || {};

  let totalSpent = 0;
  let totalPossible = 0;
  let sitesCount = Object.keys(limits).length;

  Object.entries(limits).forEach(([h, cfg]) => {
    const spent = todayData[h] || 0;
    totalSpent += spent;
    totalPossible += cfg.limit;
  });

  const saved = Math.max(0, totalPossible - totalSpent);
  const focusPct = totalPossible > 0 ? Math.round(100 - (totalSpent / totalPossible) * 100) : 100;
  
  document.getElementById("totalToday").textContent = formatTime(totalSpent);
  document.getElementById("sitesLimited").textContent = sitesCount;
  document.getElementById("savedTime").textContent = formatTime(saved);
  document.getElementById("focusScore").textContent = getFocusGrade(focusPct);

  // Breakdown bars
  const breakdown = document.getElementById("statsBreakdown");
  const entries = Object.entries(limits);
  if (entries.length === 0) {
    breakdown.innerHTML = `<div style="text-align:center;color:#888;font-size:12px;padding:20px;font-weight:700;">No sites tracked yet</div>`;
    return;
  }

  breakdown.innerHTML = "";
  entries
    .sort((a, b) => (todayData[b[0]] || 0) - (todayData[a[0]] || 0))
    .forEach(([hostname, cfg]) => {
      const spent = todayData[hostname] || 0;
      const pct = Math.min(100, (spent / cfg.limit) * 100);
      const barColor = pct >= 90 ? "#FF3CAC" : pct >= 70 ? "#FF6B00" : cfg.color || "#FFE600";

      const el = document.createElement("div");
      el.className = "stat-bar-item";
      el.innerHTML = `
        <div class="stat-bar-label">
          <span>${hostname}</span>
          <span>${formatTime(spent)} / ${formatTime(cfg.limit)}</span>
        </div>
        <div class="stat-bar">
          <div class="stat-bar-fill" style="width:${pct}%;background:${barColor}">
            ${pct > 20 ? Math.round(pct) + "%" : ""}
          </div>
        </div>
      `;
      breakdown.appendChild(el);
    });
}

function getFocusGrade(pct) {
  if (pct >= 90) return "A+";
  if (pct >= 75) return "A";
  if (pct >= 60) return "B";
  if (pct >= 45) return "C";
  if (pct >= 30) return "D";
  return "F";
}

// ── Modal ─────────────────────────────────────
function setupModal() {
  document.getElementById("modalClose").addEventListener("click", closeModal);
  document.getElementById("modalCancel").addEventListener("click", closeModal);
  document.getElementById("modalOverlay").addEventListener("click", (e) => {
    if (e.target === document.getElementById("modalOverlay")) closeModal();
  });

  // Presets
  document.querySelectorAll(".preset-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.getElementById("inputMinutes").value = btn.dataset.min;
    });
  });

  // Color picker
  document.querySelectorAll(".color-dot").forEach(dot => {
    dot.addEventListener("click", () => {
      document.querySelectorAll(".color-dot").forEach(d => d.classList.remove("selected"));
      dot.classList.add("selected");
      selectedColor = dot.dataset.color;
    });
  });

  // Save
  document.getElementById("modalSave").addEventListener("click", saveSite);
}

function openModal(hostname = null) {
  editingHostname = hostname;
  const limits = allData?.limits || {};
  const modal = document.getElementById("modalOverlay");
  const title = document.getElementById("modalTitle");

  if (hostname && limits[hostname]) {
    title.textContent = `✏️ EDIT: ${hostname}`;
    document.getElementById("inputDomain").value = hostname;
    document.getElementById("inputDomain").disabled = true;
    const mins = Math.round(limits[hostname].limit / 60);
    document.getElementById("inputMinutes").value = mins;
    selectedColor = limits[hostname].color || "#FFE600";
  } else {
    title.textContent = "➕ ADD SITE LIMIT";
    document.getElementById("inputDomain").value = hostname || currentHostname || "";
    document.getElementById("inputDomain").disabled = !!hostname;
    document.getElementById("inputMinutes").value = "";
    selectedColor = "#FFE600";
  }

  // Update color selection UI
  document.querySelectorAll(".color-dot").forEach(d => {
    d.classList.toggle("selected", d.dataset.color === selectedColor);
  });

  modal.classList.add("open");
}

function closeModal() {
  document.getElementById("modalOverlay").classList.remove("open");
  editingHostname = null;
  document.getElementById("inputDomain").disabled = false;
}

async function saveSite() {
  const domain = document.getElementById("inputDomain").value.trim()
    .replace(/^https?:\/\//, "").replace("www.", "").split("/")[0];
  const minutes = parseInt(document.getElementById("inputMinutes").value);

  if (!domain) {
    document.getElementById("inputDomain").classList.add("shake");
    setTimeout(() => document.getElementById("inputDomain").classList.remove("shake"), 300);
    return;
  }
  if (!minutes || minutes < 1) {
    document.getElementById("inputMinutes").classList.add("shake");
    setTimeout(() => document.getElementById("inputMinutes").classList.remove("shake"), 300);
    return;
  }

  await sendMsg({
    type: "SAVE_LIMIT",
    hostname: domain,
    cfg: { limit: minutes * 60, enabled: true, color: selectedColor }
  });

  closeModal();
  await loadAllData();
  await refreshCurrentSite();
}

// ── Tabs ──────────────────────────────────────
function setupTabs() {
  document.querySelectorAll(".tab-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      const target = btn.dataset.tab;
      document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
      document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
      btn.classList.add("active");
      document.getElementById(`tab-${target}`).classList.add("active");
      if (target === "stats") renderStats();
    });
  });
}

// ── Buttons ───────────────────────────────────
function setupButtons() {
  document.getElementById("addCurrentBtn").addEventListener("click", () => {
    openModal(null);
  });
  document.getElementById("optionsBtn").addEventListener("click", () => {
    chrome.runtime.openOptionsPage();
  });
}

// ── Helpers ───────────────────────────────────
function formatTime(seconds) {
  if (!seconds || seconds < 0) return "0s";
  const s = Math.round(seconds);
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${m}m`;
  if (m > 0) return `${m}m ${sec}s`;
  return `${sec}s`;
}

function getDomainEmoji(hostname) {
  const map = {
    "youtube.com": "📺", "twitter.com": "🐦", "x.com": "🐦",
    "instagram.com": "📸", "facebook.com": "👥", "reddit.com": "🤖",
    "tiktok.com": "🎵", "netflix.com": "🎬", "twitch.tv": "🎮",
    "linkedin.com": "💼", "github.com": "💻", "google.com": "🔍",
    "amazon.com": "📦", "whatsapp.com": "💬", "discord.com": "🎮",
    "spotify.com": "🎵", "pinterest.com": "📌", "snapchat.com": "👻"
  };
  return map[hostname] || "🌐";
}

function sendMsg(msg) {
  return chrome.runtime.sendMessage(msg);
}
