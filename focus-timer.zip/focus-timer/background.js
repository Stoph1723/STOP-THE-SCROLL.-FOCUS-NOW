// =============================================
// FOCUS TIMER — Background Service Worker
// =============================================

let tracking = { hostname: null, startTime: null };

// ── Init ──────────────────────────────────────
chrome.runtime.onInstalled.addListener(async () => {
  const settings = await getSettings();
  if (!settings) {
    await chrome.storage.local.set({
      settings: {
        notifications: true,
        warningPercent: 80,
        strictMode: false,
        allowOverride: true,
        overrideCooldown: 30,
        showBadge: true,
        focusMode: false,
        whitelistOnFocus: ["google.com", "github.com"]
      },
      limits: {},
      dailyTime: {},
      blocked: {},
      focusSession: null
    });
  }
  scheduleAlarms();
  console.log("[FocusTimer] Installed & ready.");
});

chrome.runtime.onStartup.addListener(() => {
  scheduleAlarms();
  restoreTracking();
});

function scheduleAlarms() {
  chrome.alarms.create("checkLimits", { periodInMinutes: 1 });
  chrome.alarms.create("dailyReset", {
    when: getNextMidnight(),
    periodInMinutes: 1440
  });
}

function getNextMidnight() {
  const now = new Date();
  const midnight = new Date(now);
  midnight.setHours(24, 0, 0, 0);
  return midnight.getTime();
}

// ── Tab Tracking ─────────────────────────────
chrome.tabs.onActivated.addListener(async (info) => {
  await saveActiveTime();
  await startTracking(info.tabId);
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.active) {
    await saveActiveTime();
    await startTracking(tabId);
  }
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await saveActiveTime();
    tracking = { hostname: null, startTime: null };
    await chrome.storage.local.set({ tracking });
  } else {
    const [tab] = await chrome.tabs.query({ active: true, windowId });
    if (tab) await startTracking(tab.id);
  }
});

chrome.tabs.onRemoved.addListener(async () => {
  await saveActiveTime();
});

async function startTracking(tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    if (!tab?.url || !tab.url.startsWith("http")) {
      tracking = { hostname: null, startTime: null };
      await chrome.storage.local.set({ tracking });
      return;
    }
    const hostname = extractHostname(tab.url);
    tracking = { hostname, startTime: Date.now(), tabId };
    await chrome.storage.local.set({ tracking });
    await checkSiteBlocked(tabId, hostname);
    updateBadge(hostname);
  } catch (e) {}
}

async function saveActiveTime() {
  const stored = await chrome.storage.local.get("tracking");
  const t = stored.tracking || tracking;
  if (!t?.hostname || !t?.startTime) return;

  const elapsed = (Date.now() - t.startTime) / 1000;
  if (elapsed < 1) return;

  await addTime(t.hostname, elapsed);
  tracking = { hostname: null, startTime: null };
  await chrome.storage.local.set({ tracking: {} });
}

async function restoreTracking() {
  const stored = await chrome.storage.local.get("tracking");
  if (stored.tracking?.hostname) {
    tracking = stored.tracking;
  }
}

// ── Time Storage ──────────────────────────────
function today() {
  return new Date().toISOString().split("T")[0];
}

async function addTime(hostname, seconds) {
  const data = await chrome.storage.local.get("dailyTime");
  const dailyTime = data.dailyTime || {};
  const date = today();
  if (!dailyTime[date]) dailyTime[date] = {};
  dailyTime[date][hostname] = (dailyTime[date][hostname] || 0) + seconds;
  await chrome.storage.local.set({ dailyTime });
}

async function getDailyTime(hostname) {
  const data = await chrome.storage.local.get(["dailyTime", "tracking"]);
  const dailyTime = data.dailyTime || {};
  const stored = (dailyTime[today()] || {})[hostname] || 0;

  // Add live elapsed time if currently tracking this hostname
  const t = data.tracking || tracking;
  if (t?.hostname === hostname && t?.startTime) {
    return stored + (Date.now() - t.startTime) / 1000;
  }
  return stored;
}

// ── Limit Checking ────────────────────────────
chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === "checkLimits") await checkAllLimits();
  if (alarm.name === "dailyReset") await resetDaily();
});

async function checkAllLimits() {
  const data = await chrome.storage.local.get(["limits", "settings"]);
  const limits = data.limits || {};
  const settings = data.settings || {};

  for (const [hostname, cfg] of Object.entries(limits)) {
    if (!cfg.enabled) continue;
    const spent = await getDailyTime(hostname);
    const pct = (spent / cfg.limit) * 100;

    if (pct >= 100) {
      await blockHostname(hostname);
      if (settings.notifications) sendNotification(hostname, "blocked");
    } else if (pct >= (settings.warningPercent || 80) && !cfg.warned) {
      if (settings.notifications) sendNotification(hostname, "warning");
      limits[hostname].warned = true;
      await chrome.storage.local.set({ limits });
    }
  }
}

async function checkSiteBlocked(tabId, hostname) {
  const data = await chrome.storage.local.get(["limits", "blocked"]);
  const limits = data.limits || {};
  const blocked = data.blocked || {};

  if (!limits[hostname]?.enabled) return;

  // Check if currently blocked
  if (blocked[hostname]) {
    const { overrideUntil } = blocked[hostname];
    if (!overrideUntil || Date.now() > overrideUntil) {
      redirectToBlocked(tabId, hostname);
      return;
    }
  }

  // Check limit
  const spent = await getDailyTime(hostname);
  if (spent >= limits[hostname].limit) {
    await blockHostname(hostname);
    redirectToBlocked(tabId, hostname);
  }
}

async function blockHostname(hostname) {
  const data = await chrome.storage.local.get("blocked");
  const blocked = data.blocked || {};
  if (!blocked[hostname]) {
    blocked[hostname] = { blockedAt: Date.now(), overrideUntil: null };
    await chrome.storage.local.set({ blocked });
  }
}

async function unblockHostname(hostname) {
  const data = await chrome.storage.local.get(["blocked", "settings"]);
  const blocked = data.blocked || {};
  const settings = data.settings || {};
  const cooldown = (settings.overrideCooldown || 30) * 60 * 1000;
  blocked[hostname] = { ...blocked[hostname], overrideUntil: Date.now() + cooldown };
  await chrome.storage.local.set({ blocked });
}

function redirectToBlocked(tabId, hostname) {
  const url = chrome.runtime.getURL(`blocked.html?site=${encodeURIComponent(hostname)}`);
  chrome.tabs.update(tabId, { url }).catch(() => {});
}

// ── Daily Reset ───────────────────────────────
async function resetDaily() {
  const data = await chrome.storage.local.get(["limits", "dailyTime"]);
  const limits = data.limits || {};
  const dailyTime = data.dailyTime || {};

  // Keep only last 7 days
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 7);
  for (const date of Object.keys(dailyTime)) {
    if (new Date(date) < cutoff) delete dailyTime[date];
  }

  // Reset warned flags
  for (const h of Object.keys(limits)) limits[h].warned = false;

  // Clear blocks
  await chrome.storage.local.set({ limits, dailyTime, blocked: {} });
  scheduleAlarms();
}

// ── Badge ─────────────────────────────────────
async function updateBadge(hostname) {
  const data = await chrome.storage.local.get(["limits", "settings"]);
  const limits = data.limits || {};
  const settings = data.settings || {};
  if (!settings.showBadge || !limits[hostname]?.enabled) {
    chrome.action.setBadgeText({ text: "" });
    return;
  }
  const spent = await getDailyTime(hostname);
  const remaining = Math.max(0, limits[hostname].limit - spent);
  const mins = Math.ceil(remaining / 60);
  chrome.action.setBadgeText({ text: mins > 99 ? "99+" : `${mins}` });
  chrome.action.setBadgeBackgroundColor({
    color: remaining < 300 ? "#FF3CAC" : "#FFE600"
  });
}

// ── Notifications ─────────────────────────────
function sendNotification(hostname, type) {
  const msgs = {
    warning: { title: "⚠️ Almost Out of Time!", body: `You're nearly at your limit for ${hostname}!` },
    blocked: { title: "🚫 Time's Up!", body: `You've hit your daily limit for ${hostname}.` }
  };
  const msg = msgs[type];
  chrome.notifications.create(`${type}-${hostname}-${Date.now()}`, {
    type: "basic",
    iconUrl: "icons/icon.svg",
    title: msg.title,
    message: msg.body
  });
}

// ── Helpers ───────────────────────────────────
function extractHostname(url) {
  try {
    return new URL(url).hostname.replace("www.", "");
  } catch {
    return null;
  }
}

async function getSettings() {
  const data = await chrome.storage.local.get("settings");
  return data.settings || null;
}

// ── Messages from Popup/Content ───────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  handleMessage(msg, sender).then(sendResponse);
  return true;
});

async function handleMessage(msg, sender) {
  switch (msg.type) {
    case "GET_STATUS": {
      const data = await chrome.storage.local.get(["limits", "blocked", "tracking", "settings"]);
      const hostname = msg.hostname;
      const limits = data.limits || {};
      const blocked = data.blocked || {};
      const cfg = limits[hostname] || null;
      const spent = cfg ? await getDailyTime(hostname) : 0;
      const isBlocked = !!blocked[hostname] && (!blocked[hostname].overrideUntil || Date.now() < blocked[hostname].overrideUntil);
      return { hostname, cfg, spent, isBlocked, tracking: data.tracking };
    }
    case "GET_ALL_STATS": {
      const data = await chrome.storage.local.get(["limits", "dailyTime", "blocked", "settings"]);
      const limits = data.limits || {};
      const dailyTime = data.dailyTime || {};
      // Enrich with live time
      const todayData = dailyTime[today()] || {};
      const liveTracking = data.tracking || tracking;
      if (liveTracking?.hostname && liveTracking?.startTime) {
        const h = liveTracking.hostname;
        todayData[h] = (todayData[h] || 0) + (Date.now() - liveTracking.startTime) / 1000;
      }
      return { limits, dailyTime, todayData, blocked: data.blocked || {}, settings: data.settings };
    }
    case "SAVE_LIMIT": {
      const data = await chrome.storage.local.get("limits");
      const limits = data.limits || {};
      limits[msg.hostname] = { ...limits[msg.hostname], ...msg.cfg, warned: false };
      await chrome.storage.local.set({ limits });
      return { ok: true };
    }
    case "DELETE_LIMIT": {
      const data = await chrome.storage.local.get("limits");
      const limits = data.limits || {};
      delete limits[msg.hostname];
      await chrome.storage.local.set({ limits });
      return { ok: true };
    }
    case "TOGGLE_LIMIT": {
      const data = await chrome.storage.local.get("limits");
      const limits = data.limits || {};
      if (limits[msg.hostname]) {
        limits[msg.hostname].enabled = !limits[msg.hostname].enabled;
        await chrome.storage.local.set({ limits });
      }
      return { ok: true };
    }
    case "OVERRIDE": {
      await unblockHostname(msg.hostname);
      return { ok: true };
    }
    case "SAVE_SETTINGS": {
      await chrome.storage.local.set({ settings: msg.settings });
      return { ok: true };
    }
    case "RESET_SITE": {
      const data = await chrome.storage.local.get(["dailyTime", "blocked"]);
      const dailyTime = data.dailyTime || {};
      const blocked = data.blocked || {};
      if (dailyTime[today()]) delete dailyTime[today()][msg.hostname];
      delete blocked[msg.hostname];
      await chrome.storage.local.set({ dailyTime, blocked });
      return { ok: true };
    }
    default:
      return { error: "Unknown message" };
  }
}
